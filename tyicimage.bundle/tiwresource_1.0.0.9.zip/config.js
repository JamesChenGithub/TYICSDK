var Config = {
  companyId: 100001,
  logo: 'https://tedu.qcloudtrtc.com/img/tic.643fc1ab.png',
  loginUrl: 'https://www.qq.com'
}
